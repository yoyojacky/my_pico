class DecompIO:
    ""

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass


def decompress():
    pass
