class BytesIO:
    ""

    def close():
        pass

    def flush():
        pass

    def getvalue():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def seek():
        pass

    def write():
        pass


class FileIO:
    ""

    def close():
        pass

    def flush():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def readlines():
        pass

    def seek():
        pass

    def tell():
        pass

    def write():
        pass


class StringIO:
    ""

    def close():
        pass

    def flush():
        pass

    def getvalue():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def seek():
        pass

    def write():
        pass


class TextIOWrapper:
    ""

    def close():
        pass

    def flush():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def readlines():
        pass

    def seek():
        pass

    def tell():
        pass

    def write():
        pass


def open():
    pass
