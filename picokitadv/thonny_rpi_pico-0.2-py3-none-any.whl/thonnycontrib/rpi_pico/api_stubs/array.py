class array:
    ""

    def append():
        pass

    def extend():
        pass
