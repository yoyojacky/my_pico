class utimeq:
    ""

    def peektime():
        pass

    def pop():
        pass

    def push():
        pass
